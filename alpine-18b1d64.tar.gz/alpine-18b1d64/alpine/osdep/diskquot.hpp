#if defined(USE_QUOTAS)

#include <sys/param.h>
#include <sys/quota.h>

include(sunquota)
#endif /* USE_QUOTAS */


